from django.apps import AppConfig


class LadderConfig(AppConfig):
    name = 'Ladder'
